Agent-based Model

Description
This agent-based model randomly moves a user-defined number of agents ('sheep') a user-defined number of steps over a DEM raster environment,
'eating' the environment at each step. The agents communicate their location and 'food' so they do not collide and have an equal share.
The colour of the environment reflects the 'height' value of the land, which changes as it is consumed by the agents. 

Data
The model uses a web-derived DEM. The agents are created within the program. 

Contents
model.py - main model code
agentframework.py - module code
readme.txt - this document
license.txt - GNU general public license notice

Installation
Extract all zipped files to chosen folder.

Instructions
1: Run command prompt within folder, or navigate to the folder path. 
2: Input required number of agents ("Sheep") and the number of steps each agent will make ("Mouthfuls").
3: The environment will open in a new window. Select Model, Run Model from the menu. 
4: Model runs. Select Model, Exit from the menu to close the model.


Support
gy17t2s@leeds.ac.uk

Author
Tristan Shearing

License
Site Location Idenification Copyright (C) 2020 Tristan Shearing

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

Full text of GNU General Public License can be found in License.txt provided in SiteLocation.zip.