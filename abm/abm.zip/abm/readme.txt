Agent-based Model

Description
This agent-based model moves a user-defined number of agents ('sheep') a user-defined number of steps over a DEM raster environment,
'eating' the environment at each step. The agents communicate their location and 'food' so they do not collide and have an equal share.
The colour of the environment reflects the 'height' value of the land, which changes as it is consumed bt the agents. 
Data
The model uses a web-derived DEM. The agents are created within the program. 

Contents

readme.txt - these instructions as a txt file
license.txt - GNU general public license notice


Installation
Extract all zipped files to chosen file location.

Instructions
1: Run Jupyter notebook within jupyter or sitelocation.py in command prompt.
2: Factor importance window opens. Select relative importance of each factor on scale of 1 to 10, and click Submit.
3: Greyscale map opens in another window. More suitable locations are shown in lighter colours.
4: Select new values on sliders to compare results.
5: 'Save this map as CSV' to save the results for further analysis or visualisation.
6: 'Close' to close program.

Support
gy17t2s@leeds.ac.uk

Author
Tristan Shearing

License
Site Location Idenification Copyright (C) 2020 Tristan Shearing

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

Full text of GNU General Public License can be found in License.txt provided in SiteLocation.zip.