# -*- coding: utf-8 -*-
"""
Created on Mon Sep  7 11:47:16 2020

@author: Tris
"""

import random

class Agent():
    #class to define actions of each agent and each action
    def __init__(self, agents, environment, x=None, y=None):
        self.agents = agents
        self.environment = environment
        self.store = 0
        if (x == None):#if no initial x value provided, random position is used
            self.x = random.randint(0,100)
        else:
            self.x = x
        if (y == None):#if no initial y value provided, random position is used
            self.y = random.randint(0,100)
        else:
            self.y = y 
        
        
    def move(self):#move agents randomly one step
        if random.random() < 0.5: #if random number is <0.5, y increases by 1
            self.y = (self.y + 1) % 100
        else: #if not, y decreases by one
            self.y = (self.y - 1) % 100

        if random.random() < 0.5:#as above for x, independent of y
            self.x = (self.x + 1) % 100
        else:
            self.x = (self.x - 1) % 100  
        
        
    
    def eat(self): 
        if self.environment[self.y][self.x] > 10: #if the environment value<10
            self.environment[self.y][self.x] -= 10 #agents consumes 10 per step 
            self.store += 10 #10 is added to the agents' store
            
    def share_with_neighbours(self, neighbourhood):
        for agent in self.agents:
            dist = self.distance_between(agent)
            if dist <= neighbourhood: #calculates if agent is in neighbourhood
                sum = self.store + agent.store #shares stores equally 
                ave = sum /2
                self.store = ave
                agent.store = ave
                #print ("Devoured: " + str(agent.store))

    def distance_between(self, agent):#Euclidian distance between agents
        return (((self.x - agent.x)**2) + ((self.y - agent.y)**2))**0.5
       
            
                
                    