# -*- coding: utf-8 -*-
"""
Created on Tue Jul 28 14:39:20 2020

@author: Tris
"""

import requests
import bs4

#import starting positions for agents 
r = requests.get('http://www.geog.leeds.ac.uk/courses/computing/practicals/python/agent-framework/part9/data.html')
content = r.text
soup = bs4.BeautifulSoup(content, 'html.parser')
td_ys = soup.find_all(attrs={"class" : "y"})
td_xs = soup.find_all(attrs={"class" : "x"})
#print(td_ys)
#print(td_xs)

import matplotlib
matplotlib.use('TkAgg')

import tkinter
import csv
import matplotlib.pyplot
import matplotlib.animation
import agentframework
import random


#create empty environment and agents lists
environment = []
agents =[]

#user-defined number of agents and iterations
num_of_agents = int(input ("How many sheep? "))
num_of_iterations = int(input ("How many mouthfuls? "))
neighbourhood = 20 #size of area in which agents interact with each other

#import raster environment from csv txt document
with open('in.txt') as f:
    reader = csv.reader(f, quoting=csv.QUOTE_NONNUMERIC)
    #create a 2d list by assigning rows and values in columns 
    for row in reader:
        rowlist = []
        environment.append(rowlist)
        for value in row:
            rowlist.append(value)

#test environment
#matplotlib.pyplot.imshow(environment)
#matplotlib.pyplot.show()              

#testing movement of agents
#a = agentframework.Agent(agents, environment)
#print(a.y, a.x)
#a.move()
#print(a.y,a.x)

#create pyplot
fig = matplotlib.pyplot.figure(figsize=(7, 7))
ax = fig.add_axes([0, 0, 1, 1])

#build the agents, pass in initial positions and environment
for i in range(num_of_agents):
    y = int(td_ys[i].text)
    x = int(td_xs[i].text)
    agents.append(agentframework.Agent(agents, environment, y, x))
    #print (y,x,(environment[y][x]))
   

def update(frame_number):
    
    fig.clear() #creates new matplotlib figure
    
    #shuffle order of agent movements, starting with random agent
    for i in random.sample(range(num_of_agents), k=(num_of_agents)): 
        
        agents[i].move() #move agents randomly one step (from agentframework)
        agents[i].eat()  #consume value 10 of environment   
        agents[i].share_with_neighbours(neighbourhood) #share equally with 
                                                       #agents in neighbourhood
    
    matplotlib.pyplot.ylim(0, 99)
    matplotlib.pyplot.xlim(0, 99)
    matplotlib.pyplot.imshow(environment) #adds environment to fig
    
    for i in range (num_of_agents): #display agents on environment
        matplotlib.pyplot.scatter(agents[i].x, agents[i].y)


def run(): #animates the update function to animate the agents 
    animation = matplotlib.animation.FuncAnimation(fig, update, 
    frames=num_of_iterations, repeat=False)
    canvas.draw()
    

    
    
#build main GUI window   
root = tkinter.Tk()
root.wm_title("Model")
canvas = matplotlib.backends.backend_tkagg.FigureCanvasTkAgg(fig, master=root)
canvas._tkcanvas.pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)    

#build GUI menu
menu_bar = tkinter.Menu(root)
root.config(menu=menu_bar)
model_menu = tkinter.Menu(menu_bar)
menu_bar.add_cascade(label="Model", menu=model_menu)
model_menu.add_command(label="Run model", command= run)#runs animation
model_menu.add_command(label="Exit", command=root.destroy)#closes model

tkinter.mainloop() 
   